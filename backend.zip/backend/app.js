import express from "express";
import dotenv from 'dotenv'
import cors from 'cors'
import router from "./src/routes/transactionRoutes.js";

const app = express();
dotenv.config();

app.use(express.json());
app.use(cors())

const PORT = process.env.PORT || 3001;

app.use("/api", router);

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});