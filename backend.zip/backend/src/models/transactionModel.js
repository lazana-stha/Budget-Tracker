import data from "../../data/data.js";

export function getAll() {
  return data;
}

export function add(transaction) {
  data.push(transaction);
}

export function update(id, newTransaction) {
  const index = data.findIndex((transaction) => transaction.id == id);

  if (index === -1) return null;

  data[index] = newTransaction;
  return newTransaction;
}

export function deleted(id) {
  const index = data.findIndex((transaction) => transaction.id == id);

  if (index === -1) return null;

  return data.splice(index, 1);
}
