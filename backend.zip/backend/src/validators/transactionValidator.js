import { body, validationResult } from "express-validator";

export const transactionRules = [
  body("title")
    .notEmpty()
    .isString()
    .trim()
    .withMessage("Title is required, must be a string."),
  body("amount")
    .notEmpty()
    .isInt({ min: 100 })
    .withMessage("Price must be a positive integer."),
];

export const handleCarValidation = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    res.status(400).json({ errors: errors.array() });
  }
  next();
};
