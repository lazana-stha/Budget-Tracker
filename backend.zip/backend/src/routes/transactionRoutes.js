import express from "express";
import {
  getData,
  addTransaction,
  updateTransaction,
  deleteTransaction,
} from "../controllers/transactionController.js";
import {
  transactionRules,
  handleCarValidation,
} from "../validators/transactionValidator.js";

const router = express.Router();

router.get("/data", getData);
router.post("/data", transactionRules, handleCarValidation, addTransaction);
router.put("/data/:id", updateTransaction);
router.delete("/data/:id", deleteTransaction);

export default router;
