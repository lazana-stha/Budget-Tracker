import * as transactionModel from "../models/transactionModel.js";

export function getData(req, res) {
  const data = transactionModel.getAll();
  return res.status(200).json(data);
}

export function addTransaction(req, res) {
  const transaction = req.body;
  transactionModel.add(transaction);

  return res.status(201).json({
    message: "Transaction added successfully",
    data: transaction,
  });
}

export function updateTransaction(req, res) {
  const result = transactionModel.update(req.params.id, req.body);

  if (!result) {
    return res.status(404).json({ error: "Transaction not found" });
  }

  return res.json({ message: "Transaction updated successfully" });
}

export function deleteTransaction(req, res) {
  const result = transactionModel.deleted(req.params.id);

  if (!result) {
    return res.status(404).json({ error: "Transaction not found" });
  }

  return res.json({ message: "Transaction deleted successfully" });
}